# online
# ACCESS_ID = # your_access_id
# ACCESS_KEY = # your_access_key
# USERNAME = # your_username
# PASSWORD = # your_password
# ASSET_ID = # your_asset_id
# DEVICE_ID = # your_device_id
# ENDPOINT = "https://openapi.tuyacn.com"
